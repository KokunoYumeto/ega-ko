"""Exact-source R37 candidate/admission validator; emits ASCII JSON."""

import collections
import hashlib
import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest().upper()


canonical = Path(sys.argv[1])
base = Path(__file__).parent.parent
candidate_path = Path(__file__).with_name("r37-c2s1-continuation.tex")

raw = canonical.read_bytes()
require(len(raw) == 820505, "canonical byte count drift")
require(
    digest(raw)
    == "84EDBE3E83530AF2959B441796337C9DC21EAFCA6A13114A26778760FBF437AC",
    "canonical hash drift",
)
canonical_lines = raw.decode("utf-8").splitlines()

source_text = "\n".join(canonical_lines[1536:1605]) + "\n"
source = source_text.encode("utf-8")
require(len(source) == 3776, "source slice byte count drift")
require(len(source_text) == 3727, "source slice character count drift")
require(source.count(b"\n") == 69, "source slice line count drift")
require(
    digest(source)
    == "D91203350D0012E008CA3A778DD5ABB1E3A18D70641C753F6F86ECFF51F949FE",
    "source slice hash drift",
)

prefix = ("\n".join(canonical_lines[:1605]) + "\n").encode("utf-8")
require(len(prefix) == 73897, "admitted source-prefix byte count drift")
require(prefix.count(b"\n") == 1605, "admitted source-prefix line count drift")
require(
    digest(prefix)
    == "0815285B46DA35D916612CDDACB92A1DD646153FAF6AC0D15E03417F9D349182",
    "admitted source-prefix hash drift",
)
require(canonical_lines[1605] == "", "canonical line 1606 is no longer blank")
require(canonical_lines[1606] == r"\begin{env}[2.1.10]", "next source boundary drift")

candidate = candidate_path.read_bytes()
require(len(candidate) == 4073, "candidate byte count drift")
require(
    digest(candidate)
    == "A423B075B3483FC84CA580AED46C651F84543F4444805D94388CD5574114063D",
    "candidate hash drift",
)
require(not candidate.startswith(b"\xef\xbb\xbf"), "candidate has UTF-8 BOM")
require(b"\r" not in candidate and candidate.endswith(b"\n"), "candidate is not final-LF LF-only")
require(candidate.count(b"\n") == 72, "candidate LF count drift")
candidate_text = candidate.decode("utf-8")
require(len(candidate_text) == 2783, "candidate character count drift")
require("\ufffd" not in candidate_text, "candidate contains U+FFFD")
require(candidate_text.count("$") == 198, "candidate dollar delimiter count drift")
require(candidate_text.count("{") == candidate_text.count("}") == 81, "candidate brace count drift")
require(candidate_text.count(r"\phantomsection") == 2, "navigation-anchor count drift")
require("-fr" not in candidate_text, "French label suffix remains in candidate")
require(len(re.findall(r"[\uac00-\ud7a3]", candidate_text)) >= 600, "unexpectedly little Hangul")

normalize = lambda text: re.sub(r"\s+", "", text)
inline = lambda text: [
    normalize(item) for item in re.findall(r"(?<!\\)\$(.*?)(?<!\\)\$", text, re.S)
]
source_math = inline(source_text)
target_math = inline(candidate_text)
require(len(source_math) == len(target_math) == 99, "source/target inline-formula count drift")
require(
    collections.Counter(source_math) == collections.Counter(target_math),
    "source/target inline-formula multiset drift",
)
require(
    not re.findall(r"\\\[(.*?)\\\]", source_text, re.S)
    and not re.findall(r"\\\[(.*?)\\\]", candidate_text, re.S),
    "unexpected display math",
)

source_labels = re.findall(r"\\label\{([^}]+)\}", source_text)
target_labels = re.findall(r"\\label\{([^}]+)\}", candidate_text)
require(len(source_labels) == len(target_labels) == 2, "label count drift")
require([item.replace("-fr", "-ko") for item in source_labels] == target_labels, "label drift")
source_refs = re.findall(r"\\hyperref\[([^]]+)\]\{([^}]+)\}", source_text)
target_refs = re.findall(r"\\hyperref\[([^]]+)\]\{([^}]+)\}", candidate_text)
require(len(source_refs) == len(target_refs) == 1, "reference count drift")
require(
    [(label.replace("-fr", "-ko"), visible) for label, visible in source_refs] == target_refs,
    "reference target/text/order drift",
)

expected_environments = ["env", "proposition", "enumerate", "proof"]
expected_end_environments = ["env", "enumerate", "proposition", "proof"]
require(
    re.findall(r"\\begin\{([^}]+)\}", source_text)
    == re.findall(r"\\begin\{([^}]+)\}", candidate_text)
    == expected_environments,
    "begin-environment drift",
)
require(
    re.findall(r"\\end\{([^}]+)\}", source_text)
    == re.findall(r"\\end\{([^}]+)\}", candidate_text)
    == expected_end_environments,
    "end-environment drift",
)
source_events = re.findall(r"\\(begin|end)\{([^}]+)\}", source_text)
target_events = re.findall(r"\\(begin|end)\{([^}]+)\}", candidate_text)
require(source_events == target_events, "ordered environment event drift")
stack: list[str] = []
for action, environment in target_events:
    if action == "begin":
        stack.append(environment)
    else:
        require(bool(stack) and stack.pop() == environment, "target environment nesting drift")
require(not stack, "unclosed target environment")
require(
    re.findall(r"\\item\[\$(\d+\^\\circ)\$\]", source_text)
    == re.findall(r"\\item\[\$(\d+\^\\circ)\$\]", candidate_text)
    == [r"1^\circ", r"2^\circ", r"3^\circ"],
    "enumerated-condition labels drift",
)
require(
    re.findall(r"\\oldpage\[([^]]+)\]\{([^}]+)\}", source_text)
    == re.findall(r"\\oldpage\[([^]]+)\]\{([^}]+)\}", candidate_text)
    == [("II", "23")],
    "oldpage drift",
)

for phrase in [
    "등급환",
    "등급 소아이디얼",
    "부분군",
    "직합",
    "필요충분조건",
    "유한 개의 값을 제외한 모든",
    "아이디얼임을 증명",
    "정역임을",
    "최고차 동차성분",
]:
    require(phrase in candidate_text, f"required terminology/sense guard missing: {phrase}")
require("유한형" not in candidate_text, "irrelevant geometric finite-type terminology introduced")

# Canonical line 1572 contains an unquantified m in S_{n-mk}.  Admission is
# diplomatic: retain the exact formula and route the possible source issue;
# never silently normalize it to a guessed n-k or n-rk expression.
source_caveat = r"\mathfrak{p}\cap S_{n-mk}=S_{n-mk}"
require(source_text.count(source_caveat) == 1, "canonical line-1572 caveat drift")
require(candidate_text.count(source_caveat) == 1, "line-1572 formula was not preserved diplomatically")
for silent_repair in [
    r"\mathfrak{p}\cap S_{n-k}=S_{n-k}",
    r"\mathfrak{p}\cap S_{n-rk}=S_{n-rk}",
]:
    require(silent_repair not in candidate_text, "unadjudicated silent formula repair introduced")

r36_zip = base / "pub/ega-ko/release/2026-09-05-r36/01_EGA_ko_EDITABLE_SOURCES.zip"
r36_zip_bytes = r36_zip.read_bytes()
require(len(r36_zip_bytes) == 297934, "R36 source ZIP byte count drift")
require(
    digest(r36_zip_bytes)
    == "B6F509B89CE96445D6605012B6AFF42AB983F7AF0C705AB74F0C3E6C18DAA3C6",
    "R36 source ZIP hash drift",
)
with ZipFile(r36_zip) as archive:
    r36_target = archive.read("source/c2s1.tex")
require(len(r36_target) == 71548, "R36 target byte count drift")
require(
    digest(r36_target)
    == "24274A13350C1D2724F02EB1591CABD5774A9B57A5833108E94F307A2E4869D3",
    "R36 target hash drift",
)

separator_plus_candidate = b"\n" + candidate
expected = r36_target + separator_plus_candidate
private = (base / "ega/II/c2s1.tex").read_bytes()
public = (base / "pub/ega-ko/source/c2s1.tex").read_bytes()
require(private == public == expected, "private/public integrated target or exact suffix drift")
require(len(private) == 75622, "R37 integrated target byte count drift")
require(private.count(b"\n") == 1627, "R37 integrated target LF count drift")
require(b"\r" not in private and private.endswith(b"\n"), "integrated target is not final-LF LF-only")
require(
    digest(private)
    == "FA2AA45404EE63442184A43AD744DE0D03CC053C77C35DA26A0ED8044CB1A383",
    "R37 integrated target hash drift",
)

print(
    json.dumps(
        {
            "result": "PASS_R37_SOURCE_CANDIDATE_AND_INTEGRATED_MIRRORS",
            "source_lines": "1537-1605",
            "source": {
                "bytes": len(source),
                "characters": len(source_text),
                "lf_lines": source.count(b"\n"),
                "sha256": digest(source),
            },
            "admitted_source_prefix": {
                "lines": "1-1605",
                "bytes": len(prefix),
                "sha256": digest(prefix),
            },
            "candidate": {
                "bytes": len(candidate),
                "characters": len(candidate_text),
                "lf_lines": candidate.count(b"\n"),
                "sha256": digest(candidate),
            },
            "source_inline_math": len(source_math),
            "formula_multiset_exact": True,
            "labels": target_labels,
            "references": target_refs,
            "environments": expected_environments,
            "end_environments": expected_end_environments,
            "enumerated_conditions": ["1^\\circ", "2^\\circ", "3^\\circ"],
            "oldpage": "II23",
            "line_1572_source_formula_preserved": True,
            "line_1572_silent_formula_repair": False,
            "r36_body_preserved_byte_exact": True,
            "separator_plus_candidate": {
                "bytes": len(separator_plus_candidate),
                "sha256": digest(separator_plus_candidate),
            },
            "integrated_target": {
                "bytes": len(private),
                "lf_lines": private.count(b"\n"),
                "sha256": digest(private),
            },
            "correction_task_loci_already_routed": [1542, 1572, 1581, 1587],
            "next_source_line": 1607,
        },
        ensure_ascii=True,
    )
)
