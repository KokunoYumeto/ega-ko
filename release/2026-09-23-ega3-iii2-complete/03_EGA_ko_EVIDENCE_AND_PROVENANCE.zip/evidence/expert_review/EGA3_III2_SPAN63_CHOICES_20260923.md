# EGA III-2 번역 선택 기록 — 범위 63

## 범위와 권위

- 원문: 승인된 불변 R71 corrected-current ega3-7-fr.tex 2753–2853행
- 원문 식별: LF 3,387바이트, SHA-256 E6699B08878EAB7F92087B6F12986BBC50AEACB84BF63D35E931D36F18ADD571
- 번역 범위: 따름정리 7.7.8과 증명
- 번역 위치: ega/III/iii2-working.tex 7129–7231행
- 번역 범위 식별: LF 3,446바이트, SHA-256 A5C55F11F54920AF111DDE95BFD6180FA4EA46CD30264E927408127AE3BEF2C7

## 핵심 선택

1. G는 유한 계수의 국소 자유 O_X-가군 사이 사상의 여핵과 동형이다. 기존 한국어 EGA와 AGKO-T041/T042에 따라 locally free of finite type은 유한 계수의 국소 자유로 유지했다.

2. 원문 진술은 E_1→E_0를 이름 없이 도입한 뒤 증명에서 v를 사용한다. 한국어에서는 동일한 표시 사상을 v:E_1→E_0로 명시했다. 이를 프랑스어 source regression이라고 단정하지 않고 AGKO-EGA3-III2-CORR-0004라는 표기 검토 질문으로 한 번 전달했다. 프랑스어 원문은 변경하지 않았다.

3. mathscr T는 f_* mathscr Hom의 층 함자이고 T는 그 전역절 Hom 함자이다. mathscr Hom과 Hom, mathscr T와 T, 그리고 두 표현 동형을 구별했다.

4. 유한 계수 국소 자유 E_i에 대하여 Hom(E_i,F⊗M), check E_i⊗(F⊗M), (check E_i⊗F)⊗M, Hom(E_i,F)⊗M의 세 함자적 동형을 순서대로 보존했다.

5. F_i=Hom(E_i,F)는 연접이고 Y-평탄이다. Hom의 첫 변수 반변성 때문에 v:E_1→E_0는 u:F_0→F_1을 유도한다. 두 화살표의 방향을 합치지 않았다.

6. G가 v의 여핵인 데서 Hom(G,F⊗M)은 두 Hom의 핵이 된다. f_*의 왼쪽 완전성은 이 핵을 직상들의 핵으로 보내며, 여기서 따름정리 7.7.7을 적용한다. f_*를 완전 함자로 강화하지 않았다.

## 검토 경계

표기 질문 패킷은 controls/AGKO_EGA3_III2_CORR_0004_20260923.json, 2,153바이트, SHA-256 8B6C8A59B1DEC4925B32D7EF19862EDA551FB4F512F56D25B80F1937B3AF5B5A이다. 새 용어 항목은 필요하지 않았다. 내용 QA나 절별 반복 검토는 수행하지 않았다. 단일 기계적 통합 작업에서 따름정리·증명, 세 전시 수식과 세 align 블록의 수학적 골격을 확인했다.

