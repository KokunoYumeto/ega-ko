# EGA III-2 Korean production — general case and local gluing

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 2100–2188, comprising the §6.7 heading and §6.7.1. The exact source span is 4,092 UTF-8 bytes with SHA-256 206936691C5E1D23D2AF18CCECA81118C5F3E581AA57065842C909975B92A855.

The general construction retains both hypotheses on each morphism: separated and quasi-compact. With affine base but arbitrary target schemes, it restricts to products of affine opens and must establish the gluing conditions for the six local spectral functors.

The proof reduces to principal affine opens. Restricting the Cech cover is identified with tensoring its bicomplex by the localized target algebra. Two subsequent tensor identities are qualified only up to canonical isomorphism. Flatness of localization carries a projective Cartan–Eilenberg resolution to a projective Cartan–Eilenberg resolution of the restricted bicomplex, and exactness of tensoring with the localization produces the required comparison.

The integrated target slice is iii2-working.tex lines 2198–2290, 4,216 bytes, SHA-256 A99003FAAC8AB513CFD069C3220B106E2DD6D6CE83409B794C96F200B5F7B5BD. The resulting target is 99,206 bytes, SHA-256 2DEB9B5778A14FF1F53B8E55834469785D7B1E32E00EACA166078C5604F2CC31.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed one environment, one subsection, one historical page marker, and exact normalized preservation of all five display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
