# EGA III-2 Korean production — cover independence and affine targets

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 1914–2098, comprising §6.6.5–§6.6.8. The exact source span is 7,438 UTF-8 bytes with SHA-256 D301888FB326861E0C954D417D38A3527E5F84790718C6CC6886AD331CA777EC.

The c and d pages preserve the second-direction homology and cover-relative module constructions. The flat Cartan–Eilenberg comparison keeps flat resolutions distinct from projective or injective resolutions and retains all three canonical homology isomorphisms.

For cover independence, refinement runs from each finite affine cover to a finer cover. The induced bicomplex maps are only defined up to homotopy, while the resulting maps of all six biregular spectral functors are canonical isomorphisms. The Korean text therefore claims independence only up to canonical isomorphism. Their filtered inductive limit defines global hypertor.

With affine target schemes, each Cech bicomplex acquires its relevant algebra-module structure and the tensor becomes a fourfold complex over the tensor-product algebra. 사중복합체 is directly attested in the complete Korean EGA III-1 corpus. The associated quasi-coherent sheaves and their common abutment remain distinct from the underlying modules.

The integrated target slice is iii2-working.tex lines 2001–2187, 7,528 bytes, SHA-256 E2BCF7EEAB49E0E933841FE8C20871E84EAAC2511000C56C3A22465F8EADEFD9. The resulting target is 94,799 bytes, SHA-256 2EDB19C5991D2B4F17F0BEB4765815C2CB0DB20A871EDF1E693F4D66F30B66BC.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed four environments, two historical page markers, and exact normalized preservation of all twelve display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
