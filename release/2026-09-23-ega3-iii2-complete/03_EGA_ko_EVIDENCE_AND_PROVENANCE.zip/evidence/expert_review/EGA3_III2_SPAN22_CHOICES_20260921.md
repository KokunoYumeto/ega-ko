# EGA III-2 Korean production — homology invariance, homotopy, and flat tensor comparison

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 2359–2525, comprising §6.7.5–§6.7.6. The exact source span is 7,007 UTF-8 bytes with SHA-256 BF9371C9BA062B14ECDDFF3CFC4A4FC782B738060DF4F899EFBECF329A3DD7BF.

Proposition 6.7.5 retains a crucial asymmetry. A complex morphism inducing an isomorphism on homology yields isomorphisms for spectral sequences a, b, and c. The stronger condition that the morphism is a homotopy equivalence yields canonical isomorphisms for all six spectral sequences. The Korean text uses locked term AGKO-T174 and does not extend the first conclusion to a-prime, b-prime, or d.

Proposition 6.7.6 assumes that either bounded-below complex is formed componentwise from S-flat modules. Under that hypothesis, global hypertor is canonically the hypercohomology of the tensor complex under the product morphism. The affine proof preserves the projective Cartan–Eilenberg computation and the three successive natural cochain maps used in the b-prime calculation.

Independence from the selected covers is established by a square commuting only up to homotopy. The Korean text retains this qualification and does not claim strict commutativity. The final generalization is by the same gluing mechanism as §§6.7.1–6.7.2.

The integrated target slice is iii2-working.tex lines 2471–2654, 7,371 bytes, SHA-256 582BDAB975C56F62F061A9FDD56C5EC18504B5A8155107565EE52C54D0B999C2. The resulting target is 114,303 bytes, SHA-256 3DE01EF7CC59E2557B1C68FE71F2540EB02B1DC1AFFEDD7565A5FAA3CA03B459.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed two propositions, two proofs, one historical page marker, and exact normalized preservation of ten display blocks outside translated text, after restoring one source comma in that same transaction. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
