# EGA III-2 한국어 제작 — 밑변경, 아핀 실현과 표준 교환 준동형

범위: 승인된 불변 R71 corrected-current 원문 `ega3-7-fr.tex`의 2308–2448행. 환경 7.7.2와 7.7.3을 하나의 연속 제작 단위로 번역했다. 정확한 원문 범위는 LF 종결 개행을 포함하여 4,876 UTF-8바이트이며 SHA-256은 7D84C8DC5E7D813F2EDCC05AB28CDD80CEDAF80F50B6FFEAEAD887B73F7A6079이다.

환경 7.7.2에서는 $g:Y'\to Y$에 따른 $X'=X\times_YY'$와 $f':X'\to Y'$를 보존하고, $\mathscr P'_\bullet=\mathscr P_\bullet\otimes_{\mathscr O_Y}\mathscr O_{Y'}$가 준연접 $Y'$-평탄 복합체라는 형을 유지했다. $\mathscr T^{Y'}_\bullet$의 두 초코호몰로지 표기에서 $\mathscr P'^\bullet\otimes_{\mathscr O_{Y'}}\mathscr M'$와 $\mathscr P^\bullet\otimes_{\mathscr O_Y}\mathscr M'$의 텐서 바탕을 바꾸지 않았다.

$Y'$이 $A'$의 아핀 스킴일 때 층 함자 $\mathscr T^{A'}_\bullet$과 전역절 가군 함자 $T^{A'}_\bullet$을 구별했다. $\widetilde{M'}$에 값을 취한 층은 전역절 가군을 다시 층화한 것과 같고, $T^{A'}_\bullet(M')$ 자체는 그 전역절 가군이다. `mathscr T`와 `T`, 층화와 전역절을 합치지 않았다.

$Y=\operatorname{Spec}(A)$도 아핀이면 $T^{A'}_\bullet$은 $T^A_\bullet$에서 $A\to A'$로 스칼라를 확장한 함자이다. AGKO-T058의 스칼라 확장 문체를 재사용했다. 아핀 사상 $g':X'\to X$, 아핀 열린 덮개 $\mathfrak U$와 그 역상 $\mathfrak U'$을 택하고, $C^\bullet$ 복합체 등식과 각 아핀 열린집합 $U$ 및 $U'=g'^{-1}(U)$의 절 등식으로 환원하는 논증을 보존했다. 이로부터 열린집합 $U\subset Y$에 대한 제한 공식 (7.7.2.2)을 유지했다.

환경 7.7.3에서는 모든 준연접 $\mathscr O_Y$-가군 $\mathscr M$에 대하여 $\mathscr T_p(\mathscr O_Y)\otimes\mathscr M\to\mathscr T_p(\mathscr M)$이라는 표준 $\mathscr M$-함자적 준동형을 구성한다. 아핀에서의 (7.2.2) 정의가 $V\subset U$인 아핀 열린집합들의 제한과 가환한다는 `xymatrix`를 원문 그대로 보존하여 전역적으로 붙인다.

임의의 $g:Y'\to Y$에 대한 (7.7.3.2)는 $\mathscr O_{Y'}$로 텐서한 쪽에서 $\mathscr T_p^{Y'}(\mathscr O_{Y'})$로 가는 표준 준동형이다. 이는 명시된 $S,v_1,v_2,\mathscr P^{(2)}_\bullet$ 조건 아래 (6.7.11.2)의 수렴대상 특수 경우이다. 양쪽이 아핀이면 $T_p^A(A)\otimes_AA'\to T_p^{A'}(A')=T_p^A(A')$에 대응하는 층 준동형이라는 확인도 유지했다.

새 한국어 용어 항목은 만들지 않았다. 완성된 한국어 EGA III-1 및 현재 III-2의 밑변경·준연접·평탄·초코호몰로지·전역절·층화·가환 그림 문체와 AGKO-T008, T049, T058로 충분히 결박된다. 승인된 R71의 이 범위에서는 고신뢰도 프랑스어 원문 결함을 발견하지 않았으므로 별도 교정 후보를 보내지 않았다.

통합된 번역 범위는 `iii2-working.tex`의 6684–6826행, 4,887바이트, SHA-256 28B338A91C7AC45F89682153552AA20CC45D3BFCDD43D035E8FB980188F3ACCF이다. 통합 후 전체 작업 파일은 271,294바이트이며 SHA-256은 1BAC237339F911CC8B1872F5A1954C6AB8024F73C4E6DFA25F82F2014BB9F6F6이다.

범위별 내용 QA는 수행하지 않았다. 한 번의 비반복 기계적 통합 작업에서 환경 2/2, `xymatrix` 1/1, 역사적 쪽표지 1/1, 전시 블록 12/12, 태그 4/4, 금지 제어문자 0개를 확인했다. 공백과 `\text{}` 내부 언어만 정규화한 수학적 골격과 구두점은 12/12 정확히 일치한다. 전체 권 내용 검토와 전체 릴리스 출력 검증은 EGA III-2 완성 경계까지 유보한다.
