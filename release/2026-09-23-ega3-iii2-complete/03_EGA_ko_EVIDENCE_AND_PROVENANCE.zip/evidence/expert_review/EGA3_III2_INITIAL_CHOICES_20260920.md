# EGA III-2 Korean production — initial canon and choice record

Scope: admitted R71 `ega3-6-fr.tex` lines 1–95, through environments 6.1.1–6.1.2. The exact source slice is 4,651 UTF-8 bytes, SHA-256 `570D40A50471671A3395A390E4E05B69AF395446EA77B701EBFBF91BEA061043`.

The French source governs the mathematical content, formulas, quantifiers, and distinction between ordinary flatness over (Y) and cohomological flatness in dimension (n). The retained arXiv papers were read only as English semantic/type controls: arXiv:2301.11539v2 lines 199, 684, 728, and 742 for base change, flatness, and direct-image notation; arXiv:1505.01307v4 lines 195–217 and 253–257 for relative products, base change, and quasi-coherent sheaves. They do not authorize Korean spelling.

The Korean wording reuses the established corpus forms `준연접`, `평탄`, `밑변경`, `고차 직상`, `코호몰로지 함자`, `상반연속성`, and `호모토피`. `차원 n에서 Y 위에 코호몰로지적으로 평탄` is definition-bound in AGKO-T173 so it cannot be confused with ordinary (Y)-flatness. `퀸네트 공식` follows the already published Korean EGA III contents; the exact transliteration remains provisional because the bounded Korean primary shelf supplied no exact attestation. `축약` is retained for *réduit*; `기약` is rejected because it denotes irreducibility.

The live section-6 source no longer matches the admitted R71 bytes at three later loci. This initial span does not intersect them. Production therefore continues from the immutable admitted R71 packet, while the three later loci remain reversible pending an installed-successor receipt.

No per-span or sectional QA was performed. A single mechanical integration check—not a content-QA pass—confirmed the two environments, two historical page markers, one section, one subsection, and all four displayed formulas in exact order.
