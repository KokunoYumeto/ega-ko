# EGA III-2 Korean production — cohomological dimension and stalkwise hypertor

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 1227–1341, comprising §6.5.4–§6.5.7. The exact source span is 5,094 UTF-8 bytes with SHA-256 E72876661F1380D883E8AF41A78F405CBCEE9B62CFE0DCF4146A546A5D8EF20A.

The definition of finite cohomological dimension is kept stalkwise for a sheaf of rings and then transferred to the ringed space. In the locally Noetherian case, the Korean text preserves the source equivalence with regularity plus the Krull-dimension bound; it does not replace cohomological dimension by Krull dimension outside that hypothesis.

The two spectral functors remain distinct. The second spectral sequence is always regular, while both are biregular either under bounded-below hypotheses or under the stated finite-cohomological-dimension condition on S. The symmetry statement is retained only up to isomorphism and uses the canonical flip between the two fiber products.

In §6.5.7(ii), préfaisceau uses the locked Korean term 준층 under AGKO-T015, and the associated sheaf construction is stated explicitly as 층화 under AGKO-T026. This avoids the inconsistent legacy form 전층 found at some earlier corpus loci and distinguishes sheafification from a module-associated sheaf on an affine spectrum.

The integrated target slice is iii2-working.tex lines 1276–1390, 5,140 bytes, SHA-256 ABC2128C4E5470584D67C868129A1E158D70403414F9D97874D9CE25DDFEC617. The resulting target is 61,435 bytes, SHA-256 4D52DCF2C10966223168403E5D68095CF680B3D51F2EC502AE48EA9C27A6360B.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed two numbered environments, one proposition, one proof, one named theorem, one historical page marker, and exact normalized preservation of all five display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
