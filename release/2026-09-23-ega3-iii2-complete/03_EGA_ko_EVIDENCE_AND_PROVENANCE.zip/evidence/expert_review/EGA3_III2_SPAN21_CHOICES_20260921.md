# EGA III-2 Korean production — hypercohomology and local hypertor comparisons

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 2306–2357, comprising §6.7.4. The exact source span is 2,701 UTF-8 bytes with SHA-256 C9F7B039171BDEEED0783C2C7DD883EFD37BD2ED2E1C9946CB396DECFB74DCA5.

The first comparison identifies global hypertor against the identity on Y with the hypercohomology of a bounded-below quasi-coherent complex under a quasi-compact separated map. The proof uses the same finite affine cover and the one-element cover of Y.

The source then gives a substantive negative boundary: replacing O_Y by an arbitrary quasi-coherent module F does not generally produce the hypercohomology of the tensor product, even though the bicomplex in the calculation is still identified with the corresponding Cech bicomplex. The Korean text preserves both clauses and does not promote the computational identification to a false general isomorphism.

The second comparison identifies global hypertor for the two identity maps with local hypertor. After affine reduction, one-element covers make the first Cech degrees vanish and reduce each bicomplex to global sections.

The integrated target slice is iii2-working.tex lines 2409–2469, 2,903 bytes, SHA-256 4FF8DBC7B87E679083AD7E47CDDF8DA153E1E7104CBCD3C45A170CCAFB5C4DB4. The resulting target is 106,931 bytes, SHA-256 3058C7DE80BD218787EDB1E47A3A2D61FD0D73EF199376BDD34F96ADF0A3B5D9.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one remark, one historical page marker, and exact normalized preservation of both display blocks outside the necessarily translated text command, after restoring one source period in that same transaction. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
