# EGA III-2 Korean production — explicit a, a-prime, b, and b-prime pages

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 1735–1912, comprising §6.6.3–§6.6.4. The exact source span is 7,434 UTF-8 bytes with SHA-256 72A10F7359A06C80ECB5283706AD51E2AB34B4D6009728DCFC1BC3961FC4FEF4.

The a and a-prime pages are both expressed as Tor of the hypercohomology modules, but their derivations retain the distinct total and first-direction homology constructions. The b and b-prime calculations preserve the passage from bi-alternating cochains to cohomology-equivalent all-cochain and P-complex models; the text does not identify those complexes themselves.

Two already-known authority deltas occur here. At R71 lines 1794–1795, admitted R71 has Card(sigma)=-(h+1) and Card(tau)=-(k+1), while the unadmitted live leaf has 1-h and 1-k. At R71 line 1869, admitted R71 has Card(sigma)+Card(tau)=-h-2, while the live leaf has 2-h. The Korean formulas follow admitted R71 exactly and carry non-rendered comments giving the live alternatives, so both loci remain mechanically reversible. No source correction is asserted or installed.

The integrated target slice is iii2-working.tex lines 1805–1999, 7,849 bytes, SHA-256 74F5B7357BB031CA15AC403A0836695B45ECEF8BBE3970765C768F6591694FE8. The resulting target is 87,270 bytes, SHA-256 9B2C11CF74294E35E57C6E36779360AB76C76DBF88EFE38C6BBE133CE1F73C08.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed two environments, one historical page marker, and exact normalized preservation of all sixteen display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
