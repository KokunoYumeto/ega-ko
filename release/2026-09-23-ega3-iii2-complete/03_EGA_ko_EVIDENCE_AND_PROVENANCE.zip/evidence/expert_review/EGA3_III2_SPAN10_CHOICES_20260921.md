# EGA III-2 Korean production — pullback map for local hypertor

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 975–1103, comprising §6.4.4 and §6.4.5. The exact source span is 5,503 UTF-8 bytes with SHA-256 032C8079CDC9BF4F13259B4F181361680747351E49D3BC8CF7885789100E8373.

The construction keeps three map types separate. The module hypertor map is B tensor_A C-linear; sheafification gives a morphism relative to u times_S v; adjunction gives the displayed O-module homomorphism theta-sharp after pullback. The Korean text therefore retains the source's coefficient ring and base morphism at each stage.

Morphisme de bi-partial-foncteurs is rendered 두 변수에 대한 partial-함자의 사상 under AGKO-T177. This states that the bifunctor carries compatible delta-functor structures in each variable without suggesting that bi- modifies the differential operator itself. It extends the completed Korean EGA III-1 term partial-함자 transparently.

The open-immersion proof preserves both reductions. First, isomorphism is local on principal-open products and compatible with composition of pullbacks. Second, on D(f) times_S D(g), the source identifies localization with filtered colimits of copies of the original complexes whose transition maps are multiplication by powers of f and g; functoriality makes the induced hypertor transition multiplication by the matching power of f tensor g. The final use of §6.3.6 is therefore unchanged.

The integrated target slice is iii2-working.tex lines 1011–1143, 5,667 bytes, SHA-256 96AF94AE947A1FA5415C8FB84B2592B44DFE881032BA2307FECC966D6AB54856. The resulting target is 49,594 bytes, SHA-256 9F51651BE35F96A28C15F86D3611965B084E9F41A655D986959769A2115DB08E.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed one numbered environment, one named theorem, one proof, two historical page markers, and exact normalized preservation of all eight display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
