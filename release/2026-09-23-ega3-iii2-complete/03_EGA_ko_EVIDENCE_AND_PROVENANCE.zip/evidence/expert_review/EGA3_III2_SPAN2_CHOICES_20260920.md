# EGA III-2 Korean production — hypercohomology and homotopy choices

Scope: admitted R71 ega3-6-fr.tex lines 96–193, through environments 6.1.3, 6.1.4, and 6.2.1. The exact source slice is 4,771 UTF-8 bytes, SHA-256 4C058013F354D11DB31067D917DFE0CF7A64D5BBFD38EFEAF0AC7CBFB947DF93.

The French definition controls *homotopisme*: it is a morphism \(f:K^\bullet\to K'^\bullet\) admitting \(g\) in the reverse direction such that both composites are homotopic to the corresponding identity. I rendered this as 호모토피 동치사상, and the source’s object-level extension as 서로 호모토피 동치. This avoids confusing the notion with a mere homotopy between parallel maps, a strict isomorphism, or a quasi-isomorphism. AGKO-T174 records the exact distinction and keeps the surface form provisional.

The bounded Korean scholarly check found a Korea University repository thesis whose §2.4 uses 사슬 호모토피 동치 together with the defining chain-homotopy equation. That supports the 호모토피 동치 compound, but it does not independently attest the exact full noun 호모토피 동치사상; the ledger says so explicitly. The retained arXiv paper 0706.0493v3, lines 72 and 486, supplies only English semantic/type control for complexes and maps up to homotopy. It is not Korean lexical authority.

The remaining language follows the already completed Korean EGA III-1 loci 0.11.4.3, 0.12.4.1, and 0.12.4.5: 초코호몰로지, 스펙트럼 함자, 수렴대상, 정칙, 쌍정칙, 아래로 유계, 열린 덮개, and 이중복합체. In *Y est réduit à un point*, *réduit* is verbal: Y가 한 점으로 이루어져 있을 때. Rendering it as scheme-theoretic 축약 would be a mathematical error. The source’s \(C^\bullet\) notation is retained rather than silently changed to the distinct Čech notation.

The target slice occupies ega/III/iii2-working.tex lines 89–183: 4,958 UTF-8 bytes, SHA-256 9D4103B3A3FA94AC4782932552D175B586D1C05573216344296334AD572F0B0F. The complete working file is 9,455 bytes, SHA-256 D63760E84364ECC7ABEC2BA39881B460F3D7D8710A5B203C1788971213B808A0.

No per-span, sectional, or repeated content QA was performed. One non-iterated mechanical integration check confirmed the three environment identifiers, one historical page marker, one subsection, and exact normalized preservation of the three math blocks representing four displayed formulas.
