# EGA III-2 Korean production — multivariable hypertor and affine-base setup

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 1538–1621, comprising §6.5.15, the §6.6 heading, and §6.6.1. The exact source span is 3,788 UTF-8 bytes with SHA-256 `2014E6F3034836917F796748B552BAA855801205A2F0C7623A5EBD20584D69E3`.

The multivariable extension is stated for an arbitrary finite number of \(S\)-preschemes and retains the direct-sum indexing of the regular second spectral sequence. The later comparison is named a `결합법칙 스펙트럼 열`, keeping the associativity meaning rather than reducing it to a generic spectral sequence.

The §6.6 heading uses `퀸네트`, the spelling already recorded by workflow entry AGKO-TERM-E173 from the complete Korean EGA III-1 corpus. A first draft used `퀴네트`; exact consultation of the existing canon corrected that form within the same production transaction. This is corpus continuity, not a claim of newly found Korean primary attestation.

For the affine-base setup, `cochaînes alternées` is rendered `교대 코체인`. Both degree conventions are explicit: the Cech cochain index is \(-p\), while the sheaf complex has differential of degree \(-1\); the cohomological reindexing uses \(\mathscr P_{-q}^{(i)}\) in degree \(q\). Total-complex homology is identified with hypercohomology and then canonically with the space-level group, so the independence from the finite affine cover is preserved.

The integrated target slice is `iii2-working.tex` lines 1608–1689, 3,722 bytes, SHA-256 `0671242C9E160734EDA7BB9646BD8AD4E07CD0DF43CDF6EF3FF289EE7AC44522`. The resulting target is 75,250 bytes, SHA-256 `098A1AD19D72F7513D0B42D44A7C372321837CEA7CBEFDFD9618FE180FED70D8`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed two environments, one subsection, one historical page marker, and exact normalized preservation of six display blocks after restoring two source punctuation marks in that same transaction. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
