# EGA III-2 Korean production — filtered colimits and hypertor

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 499–616, comprising §6.3.5 and §6.3.6. The exact source span is 5,147 UTF-8 bytes with SHA-256 CDA8F7C6303FCAC0294FBBE741B44E4EA812026DF474E67176A8F462FB8E7D7F.

The Korean text preserves the source's distinction between the newly defined hypertor of complexes, written 초Tor under AGKO-T175, and ordinary module Tor. In §6.3.5(ii), the equality with ordinary Tor is therefore stated only after the two modules have been placed in degree zero and their projective resolutions have been completed by zeros as Cartan–Eilenberg resolutions.

For systèmes inductifs filtrants, the established Korean EGA wording 여과 귀납계 is reused. Likewise, commute à la limite inductive remains 귀납극한과 가환, and the common target of a spectral sequence remains 수렴대상. These forms are already fixed in the complete Korean EGA III-1 corpus, especially §§0.10.3.1 and 0.11.5.

Résolution libre canonique is rendered 표준 자유 분해. The defining construction is kept explicit: each term is the free module of formal linear combinations of elements of the preceding kernel. The proof then preserves the exact sequence of implications: exactness of filtered colimits, flatness of filtered colimits of free modules, commutation of homology with filtered colimits, and the resulting bijectivity for ordinary Tor and hence hypertor.

The integrated target slice is iii2-working.tex lines 521–639, 5,260 bytes, SHA-256 1EBFDBF63F7DC0203A4B09184C1E4CAFA8DD87366777A583C4AF727986D81EA5. The resulting target is 29,065 bytes, SHA-256 33AC739CD60C0D980A051A2F08B7BA2F9B65D7796A267735A06F987A14899FD4.

No per-span content QA was performed. A single non-iterated mechanical integration transaction confirmed the one named theorem, proposition, proof, historical page marker, and seven display blocks; after correcting one omitted source punctuation mark inside the first display, the seven normalized display blocks are exact. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
