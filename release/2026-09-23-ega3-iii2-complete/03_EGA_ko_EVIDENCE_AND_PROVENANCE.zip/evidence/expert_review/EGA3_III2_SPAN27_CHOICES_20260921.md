# EGA III-2 Korean production — associativity spectral functor

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2841–2901, comprising §6.8.1 and Proposition 6.8.2 with its reduction. The exact source span is 2,283 UTF-8 bytes with SHA-256 `5AAF85C720F628969279E0FEE718CC0A36AAF8C365413CF9D85CA976E191B61B`.

The subsection introduces the associativity relation for global hypertor over a partition of the finite index set. The target retains the general partition first, then the explicit notational restriction to the two consecutive blocks ({1,ldots,r}) and ({r+1,ldots,m}). The partial hypertors (mathcal T_{ullet j}) remain indexed by the blocks (I_j).

Proposition 6.8.2 introduces a canonical biregular “결합법칙 스펙트럼 함자.” Its abutment is the global hypertor of all (m) inputs, while its (E_2)-term is the local hypertor of the two partial global-hypertor objects, summed over (q_1+q_2=q). The target preserves the distinction between local (mathscr T\!or) and global (mathfrak{Tor}).

The proof canonically identifies (Y) with (Z^{(1)}	imes_S Z^{(2)}), reduces to the affine case, and explicitly defers the substantive affine construction to Corollary 6.8.3. The Korean text does not present the reduction itself as a proof of that corollary.

The integrated target slice is `iii2-working.tex` lines 3001–3066, 2,410 bytes, SHA-256 `B8FEC0F5A9392B46910FCA81543CADC4E0636E070E5297DF23849F21A6773D81`. The resulting target is 130,466 bytes, SHA-256 `228430F5E53C7226E1A193EAC8D3F9201F2697B853C6EDD3F036A1C3FCA894CB`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one subsection, one environment, one proposition, one proof, one historical page marker, and exact whitespace-normalized preservation of three display blocks after restoring one source period inside the first display before sealing. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
