# EGA III-2 Korean production — flat base change

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2972–3045, comprising §§6.9.1–6.9.2. The exact source span is 3,110 UTF-8 bytes with SHA-256 `4BDC41CA4FBF68B1BAA6B93544F26164B397197B061E862607259F3A4D4F5DA7`.

Environment 6.9.1 fixes a base-change morphism (g:S'	o S), the base-changed spaces, complexes, and maps, and asks for the relation between global hypertor formed over (S') and global hypertor over (S) tensored with (mathscr O_{S'}). The target preserves both module expressions and the separated, quasi-compact hypotheses on every (f'_i).

Proposition 6.9.2 states the canonical base-change isomorphism only under flatness of (g), as an isomorphism of delta functors in all input complexes. The proof reduces by the earlier gluing methods to affine bases (A	o A'). It keeps the exact equality of Čech complexes after scalar extension.

Flatness of (A') over (A) has two distinct uses: tensoring each projective Cartan–Eilenberg resolution still gives such a resolution over (A'), and homology of the total tensor product commutes with scalar extension. Both uses remain explicit.

The integrated target slice is `iii2-working.tex` lines 3136–3214, 3,248 bytes, SHA-256 `7AC562E2E256412876A436201F65BD9EA7ED65D63D571FCE594F426D306A24A1`. The resulting target is 136,537 bytes, SHA-256 `AB89A199046576CD62428ABE1B61AC3D8DF54B066D31E4005C56FEFC599284EC`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one subsection, one environment, one proposition, one proof, one historical page marker, and exact whitespace-normalized preservation of three display blocks after removing three display wrappers absent from the source and restoring one source comma before sealing. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
