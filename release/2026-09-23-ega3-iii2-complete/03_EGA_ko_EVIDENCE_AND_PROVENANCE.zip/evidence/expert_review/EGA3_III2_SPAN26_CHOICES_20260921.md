# EGA III-2 Korean production — finite families, unit factors, and symmetry

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2760–2839, comprising §§6.7.11–6.7.13. The exact source span is 3,706 UTF-8 bytes with SHA-256 `0DE3FE20C3F1C91BF8D277E3B8F509CE0B9650C54D129AB9DF53781C0D2DBD9C`.

Environment 6.7.11 extends global hypertor from two inputs to a finite indexed family. The target keeps the finite-family hypotheses, separated and quasi-compact maps, bounded-below quasi-coherent complexes, covariance as a delta functor in every complex separately, and the common abutment of six spectral functors. For a singleton index set, the construction is explicitly identified with hypercohomology.

Proposition 6.7.12 records invariance under adjoining unit factors. For every index outside (J), both spaces equal (S), the map is the identity, and the complex is concentrated in degree zero with term (mathscr O_S). The proof retains the single-member cover and the bicomplex concentrated in bidegree ((0,0)); no stronger cancellation principle is asserted.

Remark 6.7.13 states symmetry under exchanging the two factors. The target preserves the canonical (S)-isomorphism of products, the order swap of both maps and complexes, and the passage from swapped projective Cartan–Eilenberg triple complexes to the homology of their associated simple complexes.

The integrated target slice is `iii2-working.tex` lines 2914–2999, 3,844 bytes, SHA-256 `08A12D74CF214638CAECD2834508F2FBC51BFCC38A47A598840635223291DD11`. The resulting target is 128,055 bytes, SHA-256 `4F507BA01C9F108A77074394D14211E1C3A98DAE68502A62A6DCB879255861AC`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one environment, one proposition, one proof, one remark, and exact preservation of two display blocks after normalizing whitespace and the translated in-formula word “대신.” Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
