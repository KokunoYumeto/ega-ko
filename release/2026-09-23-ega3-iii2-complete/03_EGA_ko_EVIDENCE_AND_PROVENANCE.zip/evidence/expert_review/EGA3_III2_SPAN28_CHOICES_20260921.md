# EGA III-2 Korean production — affine associativity construction

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2903–2970, Corollary 6.8.3 and its proof. The exact source span is 2,804 UTF-8 bytes with SHA-256 `213D19387ECE1163D1A46870EF72399147AE29A25F52B060B5B7F527D107C9AF`.

The corollary gives the affine form of the associativity spectral functor. Its abutment is the global hypertor over the (m) quasi-compact (S)-schemes, while its (E_2)-term applies ordinary (operatorname{Tor}_p^A) to the two partial global hypertor modules. The target retains all three different Tor notations and their levels.

The proof takes finite affine covers, their Čech bicomplexes, and projective Cartan–Eilenberg resolutions. The tensor product of all resulting triple complexes is viewed as the tensor product of two associated simple complexes (N'_ullet) and (N''_ullet), graded by sums of total degrees. Projectivity of their components is the exact input used to identify the homology with (mathbf{Tor}_ullet^A(N'_ullet,N''_ullet)).

The required spectral sequence is then precisely (6.3.2.2), with the homology of each partial simple complex interpreted by the two partial products. Boundedness below of every input passes through the resolutions to both simple complexes and supplies the stated regularity.

The integrated target slice is `iii2-working.tex` lines 3068–3134, 2,821 bytes, SHA-256 `96ABF6BF14D52DB8DFA47698753ED713C81DEF05120F2C1E267474A83963189E`. The resulting target is 133,288 bytes, SHA-256 `4BACDA718B22A5E39940DDD63F3A1674CCBCA4C58E8E10BD5F9CE12B4CA0B0E6`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one corollary, one proof, and exact whitespace-normalized preservation of five display blocks after restoring one source comma inside the (N''_ullet) display before sealing. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
