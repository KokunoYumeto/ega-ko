# EGA III-2 Korean production — spectral base change, completion

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2696–2758, completing §6.7.10. The exact source span is 2,461 UTF-8 bytes with SHA-256 `9152786E58F883BA8520A67B573B755D6FAA8B9F0E2DB50FB4AECE7816A7F25B`.

The refinement square shows that map (6.7.10.3) is independent, in the precise essential sense used by the source, of the selected finite affine covers. The target preserves the direction of every refinement arrow and does not replace this conclusion with literal equality of the underlying chain maps.

The affine construction first yields an (A)-linear spectral-functor map, which is also (B_1otimes_A B_2)-linear. Extending scalars to (B'_1otimes_A B'_2) then produces (6.7.10.5). The Korean wording preserves this order and identifies the result with the desired sheaf-level map (6.7.10.2) only after invoking the cited affine correspondence.

The passage to the general case follows the two earlier gluing arguments. The first gluing step is reduced to the displayed localization/base-change isomorphism ((Motimes_B B')_{g'}simeq M_gotimes_{B_g}B'_{g'}); all primed and unprimed elements and rings remain distinct.

The integrated target slice is `iii2-working.tex` lines 2846–2912, 2,594 bytes, SHA-256 `4A535461F4FB37125DDC9A0EEA125C76DD7482420F849D74F21A71F7E3B5FF45`. The resulting target is 124,210 bytes, SHA-256 `7A12652E99D31239D0D70DA0CA0D44823B5E5B6B158BA1A24D97C9BBB6CD590E`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one environment close, one historical page marker, and exact whitespace-normalized preservation of four display blocks. The exact block was relocated from an accidental non-unique insertion anchor to the unique (6.7.10.3) frontier before sealing. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
