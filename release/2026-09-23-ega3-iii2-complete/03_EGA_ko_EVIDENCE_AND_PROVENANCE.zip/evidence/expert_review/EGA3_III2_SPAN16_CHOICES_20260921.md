# EGA III-2 Korean production — cover-relative global hypertor

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 1623–1733, comprising §6.6.2. The exact source span is 4,180 UTF-8 bytes with SHA-256 E8D686AABA449CCD87187BA6C255C6809ACB1D7970DE60EFB9C5FFF4E7927F05.

The two Cech bicomplexes are fed to the tensor bifunctor through the general hyperhomology-of-functors construction. Because the covers are finite and the cochains alternating, only a finite range of p occurs, uniformly in q. The Korean text preserves that uniformity before drawing the bounded-below conclusion.

At this stage the hypertor object is explicitly relative to the two chosen covers. The translation therefore does not anticipate the later cover-independence result. It retains covariance in both complex arguments and uses the established two-variable partial-functor register.

The common abutment belongs to exactly six biregular spectral functors, indexed a, b, a-prime, b-prime, c, and d. All superscripts I and II on homology and Tor are preserved verbatim because they distinguish the bicomplex direction used in each E2 page.

The integrated target slice is iii2-working.tex lines 1691–1803, 4,169 bytes, SHA-256 A3232D1843F3FB89F7891E932AA154979A5543ACED6DE9172D238EF48AE5BDA7. The resulting target is 79,420 bytes, SHA-256 F040F33D717D44433897AEA3B4C4348C18875262DEA0A8E9EB03D5F2605933D8.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed one environment, one historical page marker, and exact normalized preservation of all nine display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
