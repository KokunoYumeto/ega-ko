# EGA III-2 Korean production — global gluing of local hypertor

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 1104–1226, comprising §6.4.6 and §6.5.1–§6.5.3. The exact source span is 6,457 UTF-8 bytes with SHA-256 656605E012922D7A37362EFF8D54A6C254CC6BA219385523428229393030DAB3.

The source globalizes local hypertor in two separate gluing stages. For affine S, affine-open covers of X and Y yield local sheaves on the product opens, and §6.4.5 supplies their canonical overlap identifications. For arbitrary S, an affine-open cover of S supplies the second descent step; §6.4.2 identifies both restrictions through a common principal-open base. The Korean text preserves these stages rather than compressing them into an unsupported global derived construction.

Condition de recollement is 붙이기 조건 under existing terminology record AGKO-T022. The completed object is independent of the selected covers only up to isomorphism, exactly as stated by the source. The resulting operation is again described by AGKO-T177 as a partial-functor in each of its two variables.

Produit tensoriel externe is rendered 외부 텐서곱 under AGKO-T178. This is the sheaf on X times_S Y obtained from the two sheaves on X and Y; it is not an exterior power and not the vector outer product. The compact alternative 외적 텐서곱 was rejected because 외적 is already overloaded in Korean linear algebra and exterior-algebra usage.

The integrated target slice is iii2-working.tex lines 1145–1274, 6,699 bytes, SHA-256 A5BFC9108101CA9CB266A4B3E272EF2E3EC4906A3F6B12685209996597450CD5. The resulting target is 56,294 bytes, SHA-256 CB224CB63FCAFEEDBB156E849BFB0B7082464C3A64D0FB969808D331850DDE14.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one subsection, four numbered environments, one historical page marker, and exact normalized preservation of all three display blocks after restoring one omitted source comma during the same transaction. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
