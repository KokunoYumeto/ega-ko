# EGA III-2 Korean production — local hypertor on affine schemes

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 859–974, comprising §6.3.13 and §6.4.1–§6.4.3. The exact source span is 4,939 UTF-8 bytes with SHA-256 33DDCFDBC18C14B1F7118FD3764D5B0D647C02FC1CF274B45906D6EFC0E178B5.

In §6.3.13, homothéties defined by elements of the multiplicative set are rendered explicitly as 스칼라 곱셈 사상들. This avoids importing the geometric Korean term for a homothety into a module-theoretic statement. The proof preserves the two separate facts: localization is already bijective on the two complexes, and functoriality makes localization bijective on hypertor before flat base change is invoked.

The new definition hypertor local d'indice n is rendered 지표 n인 국소 초Tor under terminology record AGKO-T176. The form is compositional: completed Korean EGA III-1 already uses 국소 및 전역 Tor, Ext 함자, while AGKO-T175 fixes 초Tor for the complex-level hyperhomology construction. The definition remains bound to the associated quasi-coherent sheaf on the fiber product; it is not treated as a generic synonym for higher Tor.

The source's historical distinction is preserved in §6.4.2: X and Y are affine S-schemes but are viewed as S-prime-preschemes after changing the base, hence 스킴 versus 준스킴. The module-to-sheaf construction, the B-C bimodule structure, and the equality of the two fiber products are not collapsed.

The integrated target slice is iii2-working.tex lines 890–1009, 5,151 bytes, SHA-256 80097B296915B1B3D525A650A0589944ADFF1085358E56274E2F4AFF45AD851E. The resulting target is 43,926 bytes, SHA-256 7F2DF3D4CDB3E354BA64D35C127B022A8C96286EC9110C8BE54CDCA4149BAAB3.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed one subsection, one proposition, two proofs, two numbered environments, one named theorem, one historical page marker, and exact normalized preservation of all seven display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
