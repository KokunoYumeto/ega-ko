# EGA III-2 Korean production — spectral base change, first half

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2616–2695, the first half of §6.7.10. The exact source span is 3,154 UTF-8 bytes with SHA-256 `5965B5B97D8F406C0B9444E9FC11FDE70E11E12CEDA849C374747E0FCA8039F9`.

The construction starts from two commutative base-change squares. The target keeps all four maps and the hypotheses that each (f'_i) is separated and quasi-compact. The resulting arrow is a canonical (mathscr O_{Y'})-homomorphism of spectral functors for all six indices (a,a',b,b',c,d); it is not stated as an isomorphism.

In the affine reduction, each finite affine cover (mathfrak U'^{(i)}) refines the inverse-image cover (u_i^{-1}(mathfrak U^{(i)})). The Korean wording uses the established “더 세분되어” register and keeps the direction of the chosen simplicial map and of both resulting bicomplex homomorphisms.

Changing the simplicial map replaces the bicomplex homomorphism by a homotopic one. This is precisely what makes the induced homomorphism of spectral functors well defined; the target does not strengthen homotopy independence to literal chain-level equality.

The integrated target slice is `iii2-working.tex` lines 2762–2845, 3,242 bytes, SHA-256 `60E6CF1990B0F59F0F9E213840305121CC3BA638C6E4D5EF7B6215A23B4F0D72`. The resulting target is 121,616 bytes, SHA-256 `92675E3D21877E29F4787B6CA20CD33E41BA8D3A8484B51FAB8285D7F134BCB1`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one open environment, one historical page marker, and exact whitespace-normalized preservation of five display blocks. An added display wrapper around an inline spectral-functor expression was removed before sealing. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
