# EGA III-2 Korean production — coherence and reversible authority loci

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 1465–1536, comprising §6.5.13–§6.5.14. The exact source span is 3,548 UTF-8 bytes with SHA-256 `433CD923AD686B82404C465224E2C17E4F7B194655F351260684DFF299981A6D`.

The Korean proposition preserves both alternative hypothesis sets, the bounded-below condition, finite generation of every homology module, and the coherent relative-hypertor conclusion. Its proof retains the biregular spectral-sequence reduction to the degree-zero case.

Both admitted R71 and the pinned live leaf stop the last sentence of that proof after `autrement dit à son`. The apparent referent is the immediately following corollary 6.5.14. The translation therefore puts `[따름정리 (6.5.14)]` in visible editorial brackets and records the intervention in a TeX comment. Correction report `AGKO-EGA3-III2-CORR-0001` was delivered to the designated EGA correction task as a review question; this production record does not assert or install a French correction.

The proof of §6.5.14 includes the known authority delta at R71 line 1510. R71 says that (S), (X), and (Z) are Noetherian, while the unadmitted live leaf omits (S). The Korean text follows admitted R71 exactly and retains a non-rendered authority note so the locus can be rebased without ambiguity.

The integrated target slice is `iii2-working.tex` lines 1528–1606, 4,075 bytes, SHA-256 `03DCAC86FEA66E152680A178B23539045D00AB5BB4A7B64EAF100EA5E90B0647`. The resulting target is 71,527 bytes, SHA-256 `D2BB6BD8BF1B2828C653A380C47EF5C39EF866CEE40BA51D36291A95124F7713`.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed one proposition, one corollary, two proofs, one enumeration, and exact normalized preservation of the single display block. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
