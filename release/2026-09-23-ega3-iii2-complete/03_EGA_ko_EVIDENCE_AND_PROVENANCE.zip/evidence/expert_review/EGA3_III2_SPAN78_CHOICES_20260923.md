# EGA III-2 C078 번역 선택 검토 기록

## 범위와 권위

- 승인된 불변 R71 corrected-current 프랑스어 원문: section 7, 4120--4200행
- 원문 범위: LF 3,990바이트, SHA-256 `22A262591E9ECD9A5B1F7286725216686FF6BECB9E3CAC89EAA6E80D9E608862`
- 한국어 범위: `ega/III/iii2-working.tex` 8493--8573행
- 한국어 범위: LF 3,962바이트, SHA-256 `52F0D061D0B293B76D3B07743622E59F43AFC35EE013B97B3609039B7F146C17`

## 핵심 선택

1. 목록 2 A의 남은 항목에서 아딕 표지, 스펙트럼 열 미분의 첨자, 화살표 종류, 귀납극한ㆍ사영극한, 외대수, 코호몰로지 대상과 정수 범위를 exact before/after 쌍으로 보존했다.

2. B) `본문 수정`은 A) `오자`와 별도 범주이다. 제N장에 삽입된 정오표의 수정들을 $\mathbf{Err}_{\mathrm N}$과 번호로 식별한다는 각주를 그대로 남겼다.

3. Err1의 `직합`에서 `유한 직합`으로의 수정은 유한성 조건을 추가하는 실질적 수정이므로 이를 단순한 문체 교정으로 약화하지 않았다.

4. Err2의 대체 본문은 모든 stalk 환이 국소환인 환 달린 공간에서 유한 생성 $\mathscr L$과 $\mathscr L\otimes\mathscr F\simeq\mathscr O_X$를 가정한다. 앞 논증으로 각 $\mathscr L_x\simeq\mathscr O_x$를 얻은 뒤, 실제 열린 근방에서 한 절단이 생성하고 그에 의한 $\mathscr O_X|V\to\mathscr L|V$의 핵이 영임을 증명하여 가역성을 얻는다.

5. `l'unique section`은 문맥상 생성 절단 하나라는 뜻이므로 `단 하나의 절단`으로 옮겼다. 모든 가능한 생성 절단의 유일성을 주장하지 않았다.

6. 절단 $z$, germ $z_y$, stalk $\mathscr L_y$, 열린집합 $W\subset V$를 서로 구별했다. 마지막에는 $\mathscr L^{-1}\otimes\mathscr L\otimes\mathscr F$에서 $\mathscr F\simeq\mathscr L^{-1}$을 별도로 결론냈다.

## 권위와 경계

승인된 R71 대체 본문이 수학적 권위이고, 완성된 한국어 EGA I c0.tex은 `국소환 달린 공간`, `유한 생성`, `가역`, `절단`, stalk 문체를 제공한다. 가군과 stalk, 한 생성자와 유일성, 절단과 germ, 가역성과 역가군의 식별을 합치지 않았다.

## 검토 질문

- `단 하나의 절단`이 one-generator 의미를 잘 전달하면서 uniqueness 오독을 충분히 피하는가?
- 핵의 절단에서 germ 소멸을 거쳐 절단 자체의 소멸로 가는 논증이 한국어 문장에서도 분명한가?

새 용어 항목과 별도의 고신뢰도 프랑스어 원문 결함은 없었다. 범위별 내용 QA나 반복 QA는 수행하지 않았다.
