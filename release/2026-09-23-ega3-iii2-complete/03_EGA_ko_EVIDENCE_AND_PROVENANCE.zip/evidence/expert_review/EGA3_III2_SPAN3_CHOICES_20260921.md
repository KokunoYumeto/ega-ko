# EGA III-2 Korean production — quasi-coherence and spectral filtration

Scope: admitted R71 ega3-6-fr.tex lines 194–275, covering propositions 6.2.2 and 6.2.3, corollary 6.2.4, and the statement of proposition 6.2.5. The exact source slice is 3,637 UTF-8 bytes, SHA-256 470454B53EF9361278B23ADB0662227605A3263C0EBF6B0C9A1E673125DF4D7A.

This span required no new Korean coinage. The completed Korean EGA III-1 corpus supplies the controlling language directly. Definition 11.1.3 fixes a regular spectral sequence’s filtration as 이산이고 소진적; environment 11.1.4 fixes the inductive-limit language; proposition 11.1.5 uses the same filtration phrase in proof. Proposition 1.4.10 fixes 분리 준콤팩트 사상 and the quasi-coherence of higher direct images, while corollary 1.4.11 fixes the affine-restriction register.

The historical object distinction remains explicit: source *schéma* in 6.2.2 is 스킴, whereas *préschémas* in 6.2.3 is 준스킴. The source’s assertion that the canonical homomorphism in 6.2.4 is bijective is rendered 전단사 rather than weakened to a vague equivalence. Properness in 6.2.5 remains 고유 under AGKO-T117/T161. The source-inline equalities involving \(B_\infty\) and the inductive limit of \(\mathscr G_k\) remain inline; only the source’s displayed map (6.2.4.1) is displayed.

The target slice is ega/III/iii2-working.tex lines 185–278: 4,032 UTF-8 bytes, SHA-256 E1606CFA38CBC8A2CB5EB51167B0B14017C3CD399C9A441EFD22FBD79D049D99. The complete working file is 13,488 bytes, SHA-256 4864718C3F66552AAB8980791B54F596D0435E1B1A91BB052274DCC262085F4E.

No per-span, sectional, or repeated content QA was performed. One final non-iterated mechanical integration check confirmed three propositions, one corollary, three proofs, one historical page marker, and exact normalized preservation of the sole displayed formula.
