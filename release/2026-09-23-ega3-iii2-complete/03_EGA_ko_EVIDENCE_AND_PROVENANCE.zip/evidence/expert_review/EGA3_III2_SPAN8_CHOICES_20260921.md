# EGA III-2 Korean production — scalar extension and restriction

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 743–858, comprising §6.3.9–§6.3.12. The exact source span is 4,159 UTF-8 bytes with SHA-256 DD838920331A3AE48D9154DEAF4C18E96DB123D251EFD4A3FD3B339043009967.

The translation continues the established 함자적 wording for factoriel. In §6.3.9, flatness of A-prime over A makes scalar extension exact and therefore sends the chosen projective Cartan–Eilenberg resolutions to projective Cartan–Eilenberg resolutions. The Korean statement retains both the hypertor isomorphism and the two spectral-sequence isomorphisms.

For §6.3.10, the notation P-prime subscript rho is treated as restriction of scalars without adding an explanatory claim absent from the source. Application identique is rendered 동일한 대응 rather than 항등사상, because its source and target are being regarded with different coefficient-ring structures even though the underlying element map is identical. The multiplication map mu and both stages of the induced Tor map remain separately typed.

In §6.3.11, the French plural limités inférieurement applies to both P-prime and Q. Korean therefore repeats 아래로 유계인 for both complexes so the hypothesis cannot be misread as applying only to the first. The proof's equality is retained only up to canonical isomorphism, as stated by the source.

The integrated target slice is iii2-working.tex lines 769–888, 4,358 bytes, SHA-256 3876B1240CDE8A985CE7BC3FC108004A8CFEC5E07D33D3EFFCE38FC6A79A5956. The resulting target is 38,774 bytes, SHA-256 0824E415EBF8024D2318602A03772BD52FA244F537536C6A9F06A7E41F26D10E.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed two propositions, two proofs, one numbered environment, one named theorem, one historical page marker, and exact normalized preservation of all eight display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
