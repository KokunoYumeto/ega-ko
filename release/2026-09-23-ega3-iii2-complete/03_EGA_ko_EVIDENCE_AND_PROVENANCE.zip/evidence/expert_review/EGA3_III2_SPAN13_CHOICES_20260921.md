# EGA III-2 Korean production — flatness, affine pushforward, and resolutions

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 1342–1463, comprising §6.5.8–§6.5.12. The exact source span is 5,518 UTF-8 bytes with SHA-256 `3EB86458640B7CDB71BFAD9EEAA2D8B6AD9853D2404C9482BDB87FA46AC42C05`.

The vanishing statement remains relative to the base: if either quasi-coherent module is (S)-flat, the higher relative hypertor sheaves vanish. The next comparison is kept as an isomorphism of partial functors in the second complex. In §6.5.10, the parenthetical qualification “not necessarily of finite type” is explicit; the Korean text does not narrow the class of locally free modules.

The affine direct-image comparison in §6.5.11 retains both its canonical and functorial character. The product morphism, pushed-forward relative hypertor, and direct images of both complexes remain typed exactly as in the French source.

In §6.5.12, the locally free resolution on (X') is kept distinct from the auxiliary projective resolution in the category of bounded-below complexes. The choice-independence statement is grounded in the cited homotopy equivalence and uses locked term AGKO-T174, `호모토피 동치사상`; it does not assert literal equality of resolutions.

The integrated target slice is `iii2-working.tex` lines 1392–1526, 6,015 bytes, SHA-256 `957B30BAA68693A2D6E8ACD610AD83C4B0CD4C6910EC7566879D476010A33326`. The resulting target is 67,451 bytes, SHA-256 `FB8987CB34FBFD5A507B18ADA47B56BB27305C0272CE543D8359A744F089056D`.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed two propositions, three named theorems, four proofs, two historical page markers, and exact normalized preservation of all three display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
