# EGA III-2 Korean production — coherence and cohomological functors

Scope: admitted R71 ega3-6-fr.tex lines 276–401, comprising the proof of proposition 6.2.5 and all of 6.2.6–6.2.7. The exact source slice is 5,464 UTF-8 bytes, SHA-256 AE7F56469FA78BF015D5A26D28B7C76542D18262D5B5E225716663C0ED368308.

The source’s finiteness types are kept separate. A \(\Gamma(Y,\mathscr O_Y)\)-module *de type fini* is a 유한 생성 가군 under AGKO-T006/T130; 유한형 is not substituted. Proposition 11.3.3 of the completed Korean EGA III-1 fixes 쌍정칙 for the two spectral sequences, proposition 11.5.2 fixes 코호몰로지 함자, and proposition 12.4.4 fixes the phrase that \(f_*\) 귀납극한과 가환한다. Corollary 1.4.12 supplies the established 교대적 코사슬 register.

The hypothesis in 6.2.6 is deliberately on the underlying space: X의 바탕공간이 국소 뇌터. It is not strengthened to saying that \(X\) is a locally Noetherian prescheme. Cover refinement is 더 세분된 덮개, and the two commutative diagrams preserve independence of the connecting morphism. Under the stated conditions, a homotopy equivalence gives a \(\partial\)-함자의 동형사상, so compatibility with connecting morphisms is not reduced to isolated degreewise isomorphisms. Environment 6.2.7 preserves the exact index reversal \(\mathscr K^i=\mathscr K_{-i}\).

The target slice is ega/III/iii2-working.tex lines 280–407: 5,464 UTF-8 bytes, SHA-256 1D8EDD706518736A35B2167DDEBEFE41624F734652E27F1B38602D1E5CF9795A. The complete working file is 19,344 bytes, SHA-256 394B9849629DF76749B9D7CC100FB00C44ED4DA37EB052A3D41B54904572DC9F.

No per-span, sectional, or repeated content QA was performed. One non-iterated mechanical integration comparison confirmed one proof, two environments, one historical page marker, and exact normalized preservation of all five display blocks.
