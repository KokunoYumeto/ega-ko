# EGA III-2 Korean production — hypertor definition

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 402–498, comprising §6.3.1–§6.3.4. The exact source span is 4,193 UTF-8 bytes with SHA-256 CBBC0C12C7619AC1F5ABEA09BC293056A1C9CB31B75D4B1C9FD7245305AD1956.

The source defines the index-n hypertor of two complexes as the homology of the tensor product of projective Cartan–Eilenberg resolutions. The Korean text uses 초Tor under terminology record AGKO-T175. This keeps the established Korean EGA III hyperhomology family, including 초호몰로지, while retaining the conventional Roman operator Tor.

A bounded search of Korean scholarly sources found no exact mathematical use of 초Tor, 하이퍼 Tor, or hypertor. The surface form is therefore explicitly provisional and definition-bound; it is not presented as externally attested Korean usage. 고차 Tor was rejected because it can denote ordinary positive-degree Tor and would obscure the source's construction on complexes.

The surrounding vocabulary is inherited from the completed Korean EGA III-1 corpus: 사영 카르탕--아일렌베르크 분해, 호몰로지 쌍함자, 정칙, 쌍정칙, and finite cohomological dimension. No unrelated lexical modernization was introduced.

The integrated target slice is iii2-working.tex lines 418–519, 4,459 bytes, SHA-256 AB77BB2A6FACD6B8DB6C55295908AD51AC39E6CB1B1A2BF14D4D7A8EDB97F8A8. The resulting target is 23,804 bytes, SHA-256 2B43F6ECDFBB5FF5D1A7BC6857E1C763AF00DFBFA4352721E5CF4D2DA5E8EB2E.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed the expected subsection, definition, propositions, corollary, proofs, historical page marker, and three display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
