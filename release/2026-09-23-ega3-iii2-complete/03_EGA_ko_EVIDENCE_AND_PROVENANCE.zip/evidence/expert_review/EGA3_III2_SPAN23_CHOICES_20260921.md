# EGA III-2 Korean production — Künneth decomposition and coherence

Scope: admitted immutable R71 corrected-current source, `ega3-6-fr.tex` lines 2527–2614, comprising §§6.7.7–6.7.9. The exact source span is 3,607 UTF-8 bytes with SHA-256 `6855854C9F85698BBDF93C3012883DB682C5425D39B081EEEBEE6FC5236F9D23`.

Proposition 6.7.7 assumes both complexes are bounded below and that one entire family of the direct-image hypercohomology modules is (S)-flat. The resulting canonical decomposition is retained as an isomorphism of two-variable delta functors, not merely as an isomorphism of individual modules. Its proof preserves both ingredients: degeneration of spectral sequence (a) and biregularity.

Theorem 6.7.8 keeps its three hypotheses separate: boundedness below, componentwise (S)-flatness of one complex, and (S)-flatness of one entire hypercohomology family. The target calls the resulting statement the “퀸네트 공식,” following the established Korean EGA register. In the affine case, the inverse isomorphism remains explicitly induced from the displayed bicomplex morphism by the cited procedure.

Proposition 6.7.9 preserves every finiteness hypothesis needed for coherence: local noetherianness, properness, finite type on one side, boundedness below, and coherence of all homology modules. The proof distinguishes coherent local hypertor on (X) from coherent (E_2)-terms on (Y), then invokes biregularity for the conclusion.

The integrated target slice is `iii2-working.tex` lines 2656–2760, 4,069 bytes, SHA-256 `1754066807885D152D8486CC73E9C20B8FD421F0CE4B9AACAB443625CDF056D7`. The resulting target is 118,373 bytes, SHA-256 `6B52052CC5EC3A091A1CF164BEC03DDB28E2E8AED45C24308537F60B8B322559`.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed two propositions, one theorem, three proofs, one historical page marker, and exact whitespace-normalized preservation of three display blocks. The exact translated block was relocated from an accidental first-match insertion to the true volume frontier, and an added display wrapper absent from the source was removed before sealing. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
