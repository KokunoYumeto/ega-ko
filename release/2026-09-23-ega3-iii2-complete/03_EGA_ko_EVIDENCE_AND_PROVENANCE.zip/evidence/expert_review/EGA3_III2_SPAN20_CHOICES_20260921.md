# EGA III-2 Korean production — arbitrary-base gluing and theorem 6.7.3

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 2190–2304, comprising §6.7.2–§6.7.3. The exact source span is 4,690 UTF-8 bytes with SHA-256 0B69561CDC347022DC9E3DF1080CEC547CEA489C80DAFBC054DCD9386D106CEE.

The arbitrary-base step glues the affine-base constructions over an affine open cover of S. After reduction to one principal open, both Cech bicomplexes already consist of modules over the localized ring, so their tensor over the localized ring is canonically identified with their tensor over the original ring. A projective Cartan–Eilenberg resolution can likewise be chosen over the localized ring.

Theorem 6.7.3 retains the separated and quasi-compact hypotheses on both morphisms, bounded-below quasi-coherent complexes, the local associated-sheaf formula on products of affine opens, and exactly six biregular spectral functors. The formulas preserve every distinction among local sheaf hypertor, global hypertor, hypercohomology, and homology. Only sequences a and b are named Künneth sequences. For complexes concentrated in degree zero, a and a-prime coincide, b and b-prime coincide, and c and d degenerate.

The integrated target slice is iii2-working.tex lines 2292–2407, 4,820 bytes, SHA-256 929F8B6D2643242A260BE37B2274D703021C26D9397A828C233FD5D5FDFC097F. The resulting target is 104,027 bytes, SHA-256 24D200DBB33480DA7A7F3DD983019CB2B9F3697D70D46C2355280A2F213AD2BB.

No per-span content QA was performed. One non-iterated mechanical integration transaction confirmed one environment, one theorem, one historical page marker, and exact normalized preservation of five display blocks after restoring one source semicolon in that same transaction. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
