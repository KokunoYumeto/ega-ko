# EGA III-2 Korean production — functorial base change for hypertor

Scope: admitted immutable R71 corrected-current source, ega3-6-fr.tex lines 617–742, comprising §6.3.7 and §6.3.8. The exact source span is 5,227 UTF-8 bytes with SHA-256 81E0C271DA5E10A9B042D2C808D31B2C8673AF0D0D2DB617D9B26DAF1A507CAC.

The proposition retains the typed conclusion: when the first bounded-below complex consists of flat modules, the canonical identification of hypertor with the homology of the ordinary tensor complex is an isomorphism of partial-functors in the second complex. The established Korean EGA III-1 form partial-함자 is reused.

In §6.3.8, homomorphisme factoriel is rendered 함자적 준동형. Here factoriel means natural in the two complex variables, not the unrelated unique-factorization sense of factoriel for rings. The same completed Korean corpus already uses 함자적 for natural transformations and functorial isomorphisms.

Déterminé à homotopie près remains 호모토피를 제외하고 정해지는, matching the established Korean EGA III-1 register. The construction preserves the source's distinction between an A-prime-linear complex map after scalar extension, the resulting A-linear map of bicomplexes, and the induced homology map. The transitivity identity and the two induced spectral-sequence morphisms are retained exactly.

The integrated target slice is iii2-working.tex lines 641–767, 5,349 bytes, SHA-256 8372C9234C7F84F5E03619E2561288D662C0DE1A5C9726597CF57E2410BF6BB8. The resulting target is 34,415 bytes, SHA-256 86F16F164BF18D2047540FF4DEC8AFA85F5296B01356C1622363BE4424D058FE.

No per-span content QA was performed. One non-iterated mechanical integration comparison confirmed one proposition, one proof, one numbered environment, one historical page marker, and exact normalized preservation of all ten display blocks. Aggregate content and rendered-output validation remain deferred until the complete volume candidate exists.
